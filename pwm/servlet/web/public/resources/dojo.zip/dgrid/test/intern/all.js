define([
	'intern/node_modules/dojo/has!host-browser?./core/createDestroy',
	'intern/node_modules/dojo/has!host-browser?./core/addCssRule',
	'intern/node_modules/dojo/has!host-browser?./core/setClass',
	'intern/node_modules/dojo/has!host-browser?./core/columns',
	'intern/node_modules/dojo/has!host-browser?./mixins/Keyboard',
	'intern/node_modules/dojo/has!host-browser?./mixins/Selection',
	'intern/node_modules/dojo/has!host-browser?./core/stores',
	'intern/node_modules/dojo/has!host-browser?./core/_StoreMixin',
	'intern/node_modules/dojo/has!host-browser?./core/OnDemand-removeRow',
	'intern/node_modules/dojo/has!host-browser?./extensions/Pagination'
], function(){});
