define(
"dijit/form/nls/pl/validate", ({
	invalidMessage: "Wprowadzona wartość jest nieprawidłowa.",
	missingMessage: "Ta wartość jest wymagana.",
	rangeMessage: "Ta wartość jest spoza zakresu."
})
);
